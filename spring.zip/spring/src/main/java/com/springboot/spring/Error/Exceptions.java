package com.springboot.spring.Error;

public class Exceptions extends Exception{

    private static final long serialVersionUID = 1L;
	
	public Exceptions(String message) {
		super(message);
	}
    
}
