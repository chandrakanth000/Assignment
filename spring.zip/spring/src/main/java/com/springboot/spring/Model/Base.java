package com.springboot.spring.Model;

import java.io.Serializable;

public class Base implements Serializable{
    
}
