package com.springboot.spring.maintainance;

import java.util.List;
import com.springboot.spring.Model.courseM;

public class CourseMain {
    public void save(courseM course);
	
	

	public List<courseM> getCourses();
    
}
